<script setup lang="ts"></script>
<template>
  <div class="flex-auto flex flex-col justify-center items-center">
    <h2 class="text-green-400 text-4xl mb-4">Wecome!</h2>
    <p>Track your finances with Balance Sheet.</p>
  </div>
</template>
