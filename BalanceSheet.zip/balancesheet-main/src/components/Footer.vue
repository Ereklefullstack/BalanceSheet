<script setup lang="ts"></script>

<template>
  <footer class="flex justify-center items-center bg-slate-200 h-8">
    Copyright &copy; 2023 by
    <a
      href="https://www.linkedin.com/in/parsa-kalagar-910368150/"
      target="_blank"
      class="text-cyan-600"
    >
      &nbsp;Parsa Kalagar</a
    >
  </footer>
</template>
