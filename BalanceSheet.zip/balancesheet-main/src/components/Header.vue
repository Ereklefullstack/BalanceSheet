<script setup lang="ts"></script>

<template>
  <header class="w-full flex justify-between items-center p-6 bg-slate-200">
    <h1 class="text-4xl text-violet-800">Balance Sheet</h1>
    <nav class="flex gap-2">
      <router-link to="/balancesheet">Home</router-link>
      <router-link to="/balancesheet/About">About us</router-link>
    </nav>
  </header>
</template>
