export interface entry {
  id: string;
  type: string;
  amount: number;
}
